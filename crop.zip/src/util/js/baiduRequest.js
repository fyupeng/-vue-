import axios from "axios";
import { Toast } from "vant";

let loadingCount = 0;
let loading;

function startLoading() {
  if (loadingCount === 0) {
    loading = Toast.loading({
      duration: 500, // 持续展示 toast
      forbidClick: true,
    });
  }
  loadingCount++;
}

function stopLoading() {
  loadingCount--;
  if (loadingCount === 0) {
    loading.clear();
  }
}

export function baiduRequest(config) {
  let to=10000;
  if(config.timeout){
    to=config.timeout
  }
  const instance = axios.create({
    baseURL: "/baiduApi/",
    // withCredentials: true,
    timeout: to,
  });
  // request interceptor
  instance.interceptors.request.use(
    (config) => {
        /**
         * 30 秒内用户访问触发 自动更新时间戳，保证当前会话有效，超过 5 分钟（后端设计），会话失效，即需要重新登录
         */
      startLoading();
      return config;
    },
    (error) => {
      return Promise.reject(error);
    }
  );

  // response interceptor
  instance.interceptors.response.use(
    (res) => {
      let data = res.data;
      stopLoading();
      if (res.status != "200") {
        console.log("后端返回异常：" + JSON.stringify(data.msg));
        Toast.fail({
          duration: 2000,
          closeOnClick:true,
          message: data.msg || "请求出现异常",
        });
        return Promise.reject('Access denied without obtaining secret key')
      } else {
        if (data && data.status == 502) {
          Toast.fail({
            duration: 2000,
            closeOnClick:true,
            message: data.msg || "令牌异常",
          });
        }
      }
      return data;
    },
    (error) => {
      stopLoading();
      var errRes = JSON.parse(JSON.stringify(error))
      var code = errRes.code != undefined ? errRes.code : "";
      var status = errRes.status != undefined ? errRes.status : "";
      var message = errRes.message != undefined ? errRes.message : "";
      var uncaught = JSON.parse("{\"code\": \"" + code + "\", \"status\": \"" + status + "\", \"message\": \"" + message + "\"}");
      return Promise.reject(uncaught);
    }
  );
  return instance(config);
}