import $ from "jquery";
const baidu_server = "/baiduApi/oauth/2.0/token?";
const baidu_server1 = "http://localhost/9001/oauth/2.0/token?";
// const baidu_server = "https://aip.baidubce.com/oauth/2.0/token?";
const grant_type = "client_credentials";
const client_id = "4wCZa9Vp3GUztFjG3VtYsjEY"; // 应用的API Key
const client_secret = "iSMYjUURnZM0eyn4w6SSinXMV5Y0PrU7"; // 应用的Secret Key

const url =
    baidu_server +
    "grant_type=" +
    grant_type +
    "&client_id=" +
    client_id +
    "&client_secret=" +
    client_secret;

export function getAccessToken() {
    return new Promise((resolve, reject) => {
        $.ajax({
        type: "get",
        dataType: 'json',
        // jsonp:'jsoncallback',
        crossDomain: true,
        url: "http://localhost:8090/baiduApi/oauth/2.0/token?grant_type=client_credentials&client_id=4wCZa9Vp3GUztFjG3VtYsjEY&client_secret=iSMYjUURnZM0eyn4w6SSinXMV5Y0PrU7",
        success: function (data) {
            // console.log(data);
            resolve(data)
        },
        error: function (xhr, errorMessage, e) {
            console.log("系统异常！" + e);
            reject(e)
        },
        });
    })
}